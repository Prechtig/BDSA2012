﻿using System;
using System.Collections.Generic;
using Assignment39;

namespace Model
{
    class DataAccesObject
    {
        public DataAccesObject()
        {

        }

        public bool CreateTask(Task task)
        {
            return true;
        }

        public Task GetTask(uint id)
        {
            return null;
        }

        public List<Task> GetTasks(DateTime startDate, DateTime endDate)
        {
            return null;
        }
    }
}
