﻿using System;

namespace Assignment39
{
    class Task
    {
        public Task()
        {

        }
    }
}