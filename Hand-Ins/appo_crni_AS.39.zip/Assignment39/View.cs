﻿using System;
using System.Collections.Generic;
using Assignment39;

namespace UI
{
    class View
    {
        public View()
        {

        }

        public void DisplayTask(Task task)
        {

        }

        public void DisplayMonth(List<Task> task)
        {

        }
    }
}
