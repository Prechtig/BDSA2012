﻿using System;
using Controller;

namespace Assignment39
{
    class Program
    {
        static void Main(string[] args)
        {
            Controller.Controller controller = Controller.Controller.GetController();
        }
    }
}
