﻿namespace Assignment38
{
    public enum JobState
    {
        Queued, Running, Finished, Unassigned, Cancelled
    }
}